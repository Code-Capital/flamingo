@extends('layouts.dashboard')
@section('title', 'Create Page')
@section('styles')
    <style>
        .select2-container .select2-selection--multiple,
        .select2-container .select2-selection {
            width: 100% !important;
            min-height: 44px !important;
            border: 1px solid #ced4da !important;
            border-radius: 8px !important;
            line-height: 25px !important;
            font-size: 16px !important;
        }
    </style>
@endsection
@section('content')
    <div class="container px-0 px-md-2 px-lg-3">
        <div class="row mx-0 pt-5">
            <div class="col-lg-12 mb-3 mx-auto">
                <form action="{{ route('pages.store') }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    <div class="profileForm bg-white p-3 p-md-3 p-lg-5 mt-4">
                        <!-- Event Name and Event Location in a single row -->
                        <div class="row ">
                            <div class="col-md-6 mb-3">
                                <div class="form-group">
                                    <label class="mb-1 required">
                                        <span>{{ __('Page') }} Name</span>
                                    </label>
                                    <div class="form-control form-control-lg">
                                        <div class="d-flex align-items-center justify-content-between">
                                            <input class="w-100" type="text" name="name" value="{{ old('name') }}"
                                                placeholder="John Doe" required>
                                        </div>
                                    </div>
                                    @error('name')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                            <!-- Event Thumbanil -->
                            <div class="col-md-6 mb-3">
                                <div class="form-group">
                                    <label class="mb-1 required">
                                        <span>Profile Image</span>
                                    </label>
                                    <div class="form-control form-control-lg">
                                        <div class="d-flex align-items-center justify-content-between">
                                            <input class="w-100" name="profile_image" type="file" accept="images/*"
                                                required>
                                        </div>
                                    </div>
                                    @error('profile_image')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                            <!-- Event Gallery -->
                            <div class="col-md-6 mb-3">
                                <div class="form-group">
                                    <label class="mb-1">
                                        <span>Cover Image</span>
                                    </label>
                                    <div class="form-control form-control-lg">
                                        <div class="d-flex align-items-center justify-content-between">
                                            <input class="w-100" name="cover_image" type="file" accept="images/*">
                                        </div>
                                    </div>
                                    @error('cover_image')
                                        <span class="text-danger">{{ $message }}</span>
                                    @enderror
                                </div>
                            </div>
                        </div>
                        <!-- Event Interests -->
                        <div class="form-group mb-3">
                            <label class="mb-1">
                                <span>Interests</span>
                            </label>
                            <div class="d-flex align-items-center justify-content-between">
                                <select class="w-100 form-control form-select" name="interests[]" multiple required>
                                    @forelse ($interests as $interest)
                                        <option value="{{ $interest->id }}"
                                            {{ in_array($interest->id, old('interests', [])) ? 'selected' : '' }}>
                                            {{ $interest->name }} </option>
                                    @empty
                                    @endforelse
                                </select>
                            </div>
                            @error('thumbnail')
                                <span class="text-danger">{{ $message }}</span>
                            @enderror
                        </div>
                        <!-- Event Description -->
                        <div class="form-group mb-3">
                            <label class="mb-1 required">
                                <span>Description</span>
                            </label>
                            <div class="form-control form-control-lg">
                                <div class="d-flex align-items-center justify-content-between">
                                    <textarea rows="4" name="description" class="w-100" required placeholder="Describe the event rules description">{{ old('description') }}</textarea>
                                </div>
                            </div>
                            @error('description')
                                <span class="text-danger">{{ $message }}</span>
                            @enderror
                        </div>

                        <!-- Is Private Checkbox -->
                        <div class="mb-3 form-check">
                            <input type="checkbox" class="form-check-input" name="is_private" value="1"
                                {{ old('is_private') ? 'checked' : '' }} id="private">
                            <label class="form-check-label" for="private">Is Private </label>
                        </div>

                        <button type="submit" class="btn btn-primary w-100 mt-3">
                            {{ __('Create') }}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
@section('scripts')
    <script>
        $(document).ready(function() {
            $(".form-select").select2({
                placeholder: "Select interests",
                allowClear: false,
            });
        })
    </script>
@endsection
