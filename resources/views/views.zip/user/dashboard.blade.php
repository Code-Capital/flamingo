@extends('layouts.dashboard')
@section('tile', 'Dashboard')
@section('styles')
@endsection
@section('content')
@endsection
@section('scripts')
@endsection
