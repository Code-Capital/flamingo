<link rel="stylesheet" href="{{ asset('css/datatables.css') }}">
<link rel="stylesheet" href="{{ asset('css/datatables.min.css') }}">
