<div>
    <div class="d-flex align-items-center flex-column justify-content-center noResult">
        <img src="{{ asset('assets/emoji.svg') }}" alt="sad emoji">
        <h2 class="mb-0 py-2">{{ __('No result found') }}</h2>
    </div>
</div>
